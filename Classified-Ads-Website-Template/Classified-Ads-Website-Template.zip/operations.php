<?php

interface operations 
{

    function Add();
    function Update();
    function Delet();
    function Search();
   // function GetAll();

}

?>