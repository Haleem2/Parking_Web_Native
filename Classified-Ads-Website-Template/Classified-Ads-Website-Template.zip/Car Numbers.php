<?php
include_once "operations.php";
include_once "data base.php";
class Car_Numbers extends Database implements operations 
{


 ///////////////////
public function Add(){

}
public function Update(){

}
public function Delet(){

}
public function Search(){

}

}

?>